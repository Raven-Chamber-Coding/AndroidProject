package com.example.weeklyscheduleapp_project

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_preferences.*
import kotlinx.android.synthetic.main.activity_secondary.*
import org.w3c.dom.Text
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class Secondary : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondary)
        // Initialize firestore
        val db = Firebase.firestore

        // Declaring Buttons and TextViews from the activity file
        val monDate = findViewById<TextView>(R.id.mondayView)
        val monTime = findViewById<TextView>(R.id.mTimeView)
        val monTask = findViewById<TextView>(R.id.monTasks)
        val tueDate = findViewById<TextView>(R.id.tuesdayView)
        val tueTime = findViewById<TextView>(R.id.tTimeView)
        val tueTask = findViewById<TextView>(R.id.tueTasks)
        val wedDate = findViewById<TextView>(R.id.wednesdayView)
        val wedTime = findViewById<TextView>(R.id.wTimeView)
        val wedTask = findViewById<TextView>(R.id.wedTasks)
        val thurDate = findViewById<TextView>(R.id.thursdayView)
        val thurTime = findViewById<TextView>(R.id.thursTimeView)
        val thurTask = findViewById<TextView>(R.id.thursTasks)
        val friDate = findViewById<TextView>(R.id.fridayView)
        val friTime = findViewById<TextView>(R.id.fTimeView)
        val friTask = findViewById<TextView>(R.id.friTasks)
        val satDate = findViewById<TextView>(R.id.saturdayView)
        val satTime = findViewById<TextView>(R.id.satTimeView)
        val satTask = findViewById<TextView>(R.id.satTasks)
        val sunDate = findViewById<TextView>(R.id.sundayView)
        val sunTime = findViewById<TextView>(R.id.sunTimeView)
        val sunTask = findViewById<TextView>(R.id.sunTasks)
        val buttonSave = findViewById<Button>(R.id.saveBtn)
        val buttonSave2 = findViewById<Button>(R.id.saveBtn2)
        val buttonSave3 = findViewById<Button>(R.id.saveBtn3)
        val buttonSave4 = findViewById<Button>(R.id.saveBtn4)
        val buttonSave5 = findViewById<Button>(R.id.saveBtn5)
        val buttonSave6 = findViewById<Button>(R.id.saveBtn6)
        val buttonSave7 = findViewById<Button>(R.id.saveBtn7)
        val buttonShow = findViewById<Button>(R.id.showBtn)
        val buttonShow2 = findViewById<Button>(R.id.showBtn2)
        val buttonShow3 = findViewById<Button>(R.id.showBtn3)
        val buttonShow4 = findViewById<Button>(R.id.showBtn4)
        val buttonShow5 = findViewById<Button>(R.id.showBtn5)
        val buttonShow6 = findViewById<Button>(R.id.showBtn6)
        val buttonShow7 = findViewById<Button>(R.id.showBtn7)
        val textView1 = findViewById<TextView>(R.id.monAllView)
        val textView2 = findViewById<TextView>(R.id.tueAllView)
        val textView3 = findViewById<TextView>(R.id.wedAllView)
        val textView4 = findViewById<TextView>(R.id.thurAllView)
        val textView5 = findViewById<TextView>(R.id.friAllView)
        val textView6 = findViewById<TextView>(R.id.satAllView)
        val textView7 = findViewById<TextView>(R.id.sunAllView)

        // When Save Button is pressed
        buttonSave.setOnClickListener {
            if(monDate.text.toString().isNotEmpty()){

                // For First time: Creates a text file and writes string into it
                // Else: Opens the text file and writes the string
                try {
                    val fileOutputStream = openFileOutput("mytextfile.txt", Context.MODE_PRIVATE)
                    val outputWriter = OutputStreamWriter(fileOutputStream)
                    outputWriter.write(monDate.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(monTime.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(monTask.text.toString())
                    outputWriter.close()
                    Toast.makeText(baseContext, "File saved successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                Toast.makeText(applicationContext, "No input?", Toast.LENGTH_SHORT).show()
            }
        }
        // What happens when show button is pressed
        buttonShow.setOnClickListener {

            // Tries to fetch data from the text file
            try {
                val fileInputStream = openFileInput("mytextfile.txt")
                val inputReader = InputStreamReader(fileInputStream)
                val output = inputReader.readText()

                // Data is displayed in the TextView
                textView1.text = output
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // When Save Button 2 is pressed
        buttonSave2.setOnClickListener {
            if(tueDate.text.toString().isNotEmpty()){

                // For First time: Creates a text file and writes string into it
                // Else: Opens the text file and writes the string
                try {
                    val fileOutputStream = openFileOutput("mytextfile2.txt", Context.MODE_PRIVATE)
                    val outputWriter = OutputStreamWriter(fileOutputStream)
                    outputWriter.write(tueDate.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(tueTime.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(tueTask.text.toString())
                    outputWriter.close()
                    Toast.makeText(baseContext, "File saved successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                Toast.makeText(applicationContext, "No input?", Toast.LENGTH_SHORT).show()
            }
        }
        // What happens when show button is pressed
        buttonShow2.setOnClickListener {

            // Tries to fetch data from the text file
            try {
                val fileInputStream = openFileInput("mytextfile2.txt")
                val inputReader = InputStreamReader(fileInputStream)
                val output = inputReader.readText()

                // Data is displayed in the TextView
                textView2.text = output
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // When Save Button 3 is pressed
        buttonSave3.setOnClickListener {
            if(wedDate.text.toString().isNotEmpty()){

                // For First time: Creates a text file and writes string into it
                // Else: Opens the text file and writes the string
                try {
                    val fileOutputStream = openFileOutput("mytextfile3.txt", Context.MODE_PRIVATE)
                    val outputWriter = OutputStreamWriter(fileOutputStream)
                    outputWriter.write(wedDate.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(wedTime.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(wedTask.text.toString())
                    outputWriter.close()
                    Toast.makeText(baseContext, "File saved successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                Toast.makeText(applicationContext, "No input?", Toast.LENGTH_SHORT).show()
            }
        }
        // What happens when show button is pressed
        buttonShow3.setOnClickListener {

            // Tries to fetch data from the text file
            try {
                val fileInputStream = openFileInput("mytextfile3.txt")
                val inputReader = InputStreamReader(fileInputStream)
                val output = inputReader.readText()

                // Data is displayed in the TextView
                textView3.text = output
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // When Save Button 4 is pressed
        buttonSave4.setOnClickListener {
            if(thurDate.text.toString().isNotEmpty()){

                // For First time: Creates a text file and writes string into it
                // Else: Opens the text file and writes the string
                try {
                    val fileOutputStream = openFileOutput("mytextfile4.txt", Context.MODE_PRIVATE)
                    val outputWriter = OutputStreamWriter(fileOutputStream)
                    outputWriter.write(thurDate.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(thurTime.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(thurTask.text.toString())
                    outputWriter.close()
                    Toast.makeText(baseContext, "File saved successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                Toast.makeText(applicationContext, "No input?", Toast.LENGTH_SHORT).show()
            }
        }
        // What happens when show button is pressed
        buttonShow4.setOnClickListener {

            // Tries to fetch data from the text file
            try {
                val fileInputStream = openFileInput("mytextfile4.txt")
                val inputReader = InputStreamReader(fileInputStream)
                val output = inputReader.readText()

                // Data is displayed in the TextView
                textView4.text = output
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // When Save Button 5 is pressed
        buttonSave5.setOnClickListener {
            if(friDate.text.toString().isNotEmpty()){

                // For First time: Creates a text file and writes string into it
                // Else: Opens the text file and writes the string
                try {
                    val fileOutputStream = openFileOutput("mytextfile5.txt", Context.MODE_PRIVATE)
                    val outputWriter = OutputStreamWriter(fileOutputStream)
                    outputWriter.write(friDate.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(friTime.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(friTask.text.toString())
                    outputWriter.close()
                    Toast.makeText(baseContext, "File saved successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                Toast.makeText(applicationContext, "No input?", Toast.LENGTH_SHORT).show()
            }
        }
        // What happens when show button is pressed
        buttonShow5.setOnClickListener {

            // Tries to fetch data from the text file
            try {
                val fileInputStream = openFileInput("mytextfile5.txt")
                val inputReader = InputStreamReader(fileInputStream)
                val output = inputReader.readText()

                // Data is displayed in the TextView
                textView5.text = output
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // When Save Button 6 is pressed
        buttonSave6.setOnClickListener {
            if(satDate.text.toString().isNotEmpty()){

                // For First time: Creates a text file and writes string into it
                // Else: Opens the text file and writes the string
                try {
                    val fileOutputStream = openFileOutput("mytextfile6.txt", Context.MODE_PRIVATE)
                    val outputWriter = OutputStreamWriter(fileOutputStream)
                    outputWriter.write(satDate.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(satTime.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(satTask.text.toString())
                    outputWriter.close()
                    Toast.makeText(baseContext, "File saved successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                Toast.makeText(applicationContext, "No input?", Toast.LENGTH_SHORT).show()
            }
        }
        // What happens when show button is pressed
        buttonShow6.setOnClickListener {

            // Tries to fetch data from the text file
            try {
                val fileInputStream = openFileInput("mytextfile6.txt")
                val inputReader = InputStreamReader(fileInputStream)
                val output = inputReader.readText()

                // Data is displayed in the TextView
                textView6.text = output
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // When Save Button 7 is pressed
        buttonSave7.setOnClickListener {
            if(sunDate.text.toString().isNotEmpty()){

                // For First time: Creates a text file and writes string into it
                // Else: Opens the text file and writes the string
                try {
                    val fileOutputStream = openFileOutput("mytextfile7.txt", Context.MODE_PRIVATE)
                    val outputWriter = OutputStreamWriter(fileOutputStream)
                    outputWriter.write(sunDate.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(sunTime.text.toString())
                    outputWriter.write(", ")
                    outputWriter.write(sunTask.text.toString())
                    outputWriter.close()
                    Toast.makeText(baseContext, "File saved successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                Toast.makeText(applicationContext, "No input?", Toast.LENGTH_SHORT).show()
            }
        }
        // What happens when show button is pressed
        buttonShow7.setOnClickListener {

            // Tries to fetch data from the text file
            try {
                val fileInputStream = openFileInput("mytextfile7.txt")
                val inputReader = InputStreamReader(fileInputStream)
                val output = inputReader.readText()

                // Data is displayed in the TextView
                textView7.text = output
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Copying info from main to secondary
        // Monday
        mondayView.text = intent.getStringExtra("MonDate")
        mTimeView.text = intent.getStringExtra("MonTime")
        monTasks.text = intent.getStringExtra("MonTasks")

        // Tuesday
        tuesdayView.text = intent.getStringExtra("TuesDate")
        tTimeView.text = intent.getStringExtra("TuesTime")
        tueTasks.text = intent.getStringExtra("TuesTasks")

        // Wednesday
        wednesdayView.text = intent.getStringExtra("WedDate")
        wTimeView.text = intent.getStringExtra("WedTime")
        wedTasks.text = intent.getStringExtra("WedTasks")

        // Thursday
        thursdayView.text = intent.getStringExtra("ThursDate")
        thursTimeView.text = intent.getStringExtra("ThursTime")
        thursTasks.text = intent.getStringExtra("ThursTasks")

        // Friday
        fridayView.text = intent.getStringExtra("FriDate")
        fTimeView.text = intent.getStringExtra("FriTime")
        friTasks.text = intent.getStringExtra("FriTasks")

        // Saturday
        saturdayView.text = intent.getStringExtra("SatDate")
        satTimeView.text = intent.getStringExtra("SatTime")
        satTasks.text = intent.getStringExtra("SatTasks")

        // Sunday
        sundayView.text = intent.getStringExtra("SunDate")
        sunTimeView.text = intent.getStringExtra("SunTime")
        sunTasks.text = intent.getStringExtra("SunTasks")

    }
    // Nav Buttons
    fun scheduler(view:View) {
        var scheduler = Intent(this,MainActivity::class.java)
        startActivity(scheduler)
    }
    fun settings(view:View) {
        var settings = Intent(this,Preferences::class.java)
        startActivity(settings)
    }
    fun help(view:View) {
        var help = Intent(this,Help::class.java)
        startActivity(help)
    }

}