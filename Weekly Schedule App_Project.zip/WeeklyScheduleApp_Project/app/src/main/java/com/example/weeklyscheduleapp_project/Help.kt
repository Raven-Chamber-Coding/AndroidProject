package com.example.weeklyscheduleapp_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Help : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)
    }
    // nav buttons
    fun scheduler(view: View) {
        var scheduler = Intent(this,MainActivity::class.java)
        startActivity(scheduler)
    }
    fun schedule(view:View) {
        var schedule = Intent(this,Secondary::class.java)
        startActivity(schedule)
    }
    fun settings(view:View) {
        var settings = Intent(this,Preferences::class.java)
        startActivity(settings)
    }
}