package com.example.weeklyscheduleapp_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Monday Submit button
        monSubmitBtn.setOnClickListener{
            var intent = Intent(this,Secondary::class.java)
            intent.putExtra("MonTasks",tasksTextView.text.toString())
            intent.putExtra("MonDate",dateEntry.text.toString())
            intent.putExtra("MonTime",timeEntry.text.toString())
            startActivity(intent)
        }
        // Tuesday Submit button
        tSubmitBtn.setOnClickListener {
            var intent = Intent(this, Secondary::class.java)
            intent.putExtra("TuesDate", dateEntry.text.toString())
            intent.putExtra("TuesTime",timeEntry.text.toString())
            intent.putExtra("TuesTasks",tasksTextView.text.toString())
            startActivity(intent)
        }
        // Wednesday submit button
        wSubmitBtn.setOnClickListener {
            var intent = Intent(this, Secondary::class.java)
            intent.putExtra("WedDate", dateEntry.text.toString())
            intent.putExtra("WedTime", timeEntry.text.toString())
            intent.putExtra("WedTasks", tasksTextView.text.toString())
            startActivity(intent)
        }
        // Thursday submit button
        thurSubmitBtn.setOnClickListener {
            var intent = Intent(this, Secondary::class.java)
            intent.putExtra("ThursDate", dateEntry.text.toString())
            intent.putExtra("ThursTime", timeEntry.text.toString())
            intent.putExtra("ThursTasks", tasksTextView.text.toString())
            startActivity(intent)
        }
        // Friday submit button
        fSubmitBtn.setOnClickListener {
            var intent = Intent(this, Secondary::class.java)
            intent.putExtra("FriDate", dateEntry.text.toString())
            intent.putExtra("FriTime", timeEntry.text.toString())
            intent.putExtra("FriTasks", tasksTextView.text.toString())
            startActivity(intent)
        }
        // Saturday submit button
        satSubmitBtn.setOnClickListener {
            var intent = Intent(this, Secondary::class.java)
            intent.putExtra("SatDate", dateEntry.text.toString())
            intent.putExtra("SatTime", timeEntry.text.toString())
            intent.putExtra("SatTasks", tasksTextView.text.toString())
            startActivity(intent)
        }
        // Sunday submit button
        sunSubmitBtn.setOnClickListener {
            var intent = Intent(this, Secondary::class.java)
            intent.putExtra("SunDate", dateEntry.text.toString())
            intent.putExtra("SunTime", timeEntry.text.toString())
            intent.putExtra("SunTasks", tasksTextView.text.toString())
            startActivity(intent)
        }
    }

    // Nav Buttons
    fun schedule(view:View) {
        var schedule = Intent(this,Secondary::class.java)
        startActivity(schedule)
    }
    fun settings(view:View) {
        var settings = Intent(this,Preferences::class.java)
        startActivity(settings)
    }
    fun help(view:View) {
        var help = Intent(this,Help::class.java)
        startActivity(help)
    }
}